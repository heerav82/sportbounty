import Head from 'next/head';

export default function Home() {
  return (
    <div>
      <Head>
        <title>SportBounty</title>
      </Head>
      <main className="min-h-screen flex flex-col items-center justify-center">
        <h1 className="text-4xl font-bold">Welcome to SportBounty</h1>
        <p className="text-lg mt-4">Buy & sell used sports gear for kids.</p>
      </main>
    </div>
  );
}